ACC OS X — Build 002 Foundation

ISI FOLDER:
- index.html
- manifest.webmanifest
- service-worker.js
- icons/icon-192.png
- icons/icon-512.png
- icons/maskable-512.png
- README_INSTALL.txt

CARA DEPLOY DARI HP:
1. Ekstrak ZIP.
2. Pastikan semua file di atas terlihat.
3. Upload seluruh folder ACC_OS_X_Build_002 ke hosting HTTPS.
4. Buka URL hasil deploy di Chrome Android.
5. Tunggu beberapa detik.
6. Menu titik tiga Chrome → Install app / Tambahkan ke layar utama.
7. Buka ACC OS X dari ikon di Home Screen.

Jangan upload index.html saja. Seluruh folder harus ikut.
